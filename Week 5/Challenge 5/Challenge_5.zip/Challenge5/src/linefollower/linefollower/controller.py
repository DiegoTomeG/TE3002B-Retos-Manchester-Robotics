'''Importamos las librerías necesarias para la 
implementación del algoritmo'''

import rclpy
from rclpy.node import Node
import numpy as np
import cv2
from cv_bridge import CvBridge
from sensor_msgs.msg import Image
from std_msgs.msg import String
from geometry_msgs.msg import Twist

'''Realizamos la declaración del nodo'''
class Controller(Node):
    def __init__(self):
        #Inicializamos el nodo bajo el nombre de "Controller"
        super().__init__('controller')

        #Creamos la suscripción al tópico encargado de publicar la imágen capturada por la cámara
        self.bridge = CvBridge()
        self.subscription = self.create_subscription(Image, '/video_source/raw', self.camera_callback, 10)
        self.subscription
        
        #Creamos un publisher para la nueva imágen procesada
        self.new_image_processed = self.create_publisher(Image, '/image_processed', 10)
        
        #Creamos un publisher para la velocidad del robot
        self.speed_publisher = self.create_publisher(Twist, 'cmd_vel', 10)
        self.speed_configuration = Twist() #Variable en la que se asignará la velocidad del robot
        
        #Variables para el redimensionamiento de la imágen 
        self.frame_height =  60  
        self.y = 120
        self.x = 360
        
        #Inicializamos variables vacías para el procesamiento de imágenes
        self.frame = None  
        self.frame_gray = None
        self.thers = None
        self.blur = None
        self.imagen_erosionada = None

        #Variables generales para el funcionamiento del nodo
        self.umbral = 100

        self.cX = 0
        self.cY = 0

        self.cX2 = 180
        self.cY2 = 120

        self.kernel = None

        self.angle = None

        #Variables del controlador P
        self.kp = 0.2

        #Mensaje de inicialización 
        self.get_logger().info('Controller node succesfully initialized!!')


    def camera_callback(self, msg):
        try:
            #Leemos la imágen
            self.frame = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            # Reajustamos el tamaño y obtenemos la sección de interés
            self.frame = cv2.resize(self.frame, (self.x, self.y))
            self.frame = self.frame[0 : self.frame_height, :]
            #Procesamos la imágen 
            self.process_image()
            
        except Exception as e:
            #Mensaje de error en la recepción de la imágen 
            self.get_logger().info(f'Failed to convert image to CV2: {e}')

    def process_image(self):
        
        #Rotamos la imágen 180 grados
        self.frame = cv2.rotate(self.frame, cv2.ROTATE_180)

        #Convertimso a escala de grises: 
        self.frame_gray = cv2.cvtColor(self.frame, cv2.COLOR_RGB2GRAY)

        #Realizamos la binarización de la imágen 
        _,self.thers = cv2.threshold(self.frame_gray, self.umbral, 255, cv2.THRESH_BINARY)
        
        #Aplicamos medianblur
        self.blur = cv2.medianBlur(self.thers, 5)
            
        #Erosionamos la imágen 
        self.kernel = np.ones((8,8), np.uint8)  
        self.imagen_erosionada = cv2.dilate(self.blur, self.kernel, iterations=1) #DIlatación invertida por convención 
        self.imagen_erosionada = cv2.bitwise_not(self.imagen_erosionada)
        
        #Aplicamos bordes y dilatamos
        self.bound = cv2.Canny(self.imagen_erosionada, 50, 120)
        self.kernel = np.ones((3,3), np.uint8)  
        self.bound = cv2.dilate(self.bound, self.kernel, iterations=1)
        
        #Identificamos los contornos 
        self.contours, _ = cv2.findContours(self.imagen_erosionada, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        #Dibujamos un punto fijo que nos servirá para calcular la pendiente e implementar el controlador

        cv2.circle(self.frame, (self.cX2, self.cY2), 2, (255, 0, 0), -1)
            
        for contour in self.contours:
            # Calcula el momento del contorno
            self.M = cv2.moments(contour)
            # Calcula las coordenadas del centro de masa
            if self.M["m00"] != 0:
                self.cX = int(self.M["m10"] / self.M["m00"])
                self.cY = int(self.M["m01"] / self.M["m00"])
            else:
                self.cX, self.cY = 0, 0
    
            area = cv2.contourArea(contour)
    	    
            if area > 1800: 
                # Dibuja el centro de masa
                cv2.circle(self.frame, (self.cX, self.cY), 2, (0, 0, 0), -1)
                cv2.drawContours(self.frame, [contour], -1, (0,255,0),2)
                
                
     
                try:
                    #Calcualmos el nángulo
                    self.angle = -1*np.degrees(np.arctan2(self.cY - self.cY2, self.cX -self.cX2))

                    #Calculamos el seno ( normalizamos de -1 a 1)
                    angle_radians = np.radians(self.angle)
                    self.sine = 1-np.sin(angle_radians)
         
                    print(self.sine)
            
                except ZeroDivisionError:
                    print('division by zero')
                
                cv2.putText(self.frame, f"Theta: {self.sine:.2}", (self.cX - 50, self.cY - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 1, cv2.LINE_AA)       
                       
                #TRazamos una linea entre el punto fijo y el centroide
                cv2.line(self.frame, (self.cX2, self.cY2), (self.cX, self.cY), (0, 255, 0), 2)
   
                #Declaramos las velocidades            
                self.speed_configuration.linear.x = 0.1
                self.speed_configuration.angular.z = self.kp * self.sine*-1
  
            #Publicamos la velcoidad            
            self.speed_publisher.publish(self.speed_configuration)
            
            #PUblicamos la imágen con fines de depuración
            self.new_image_processed.publish(self.bridge.cv2_to_imgmsg(self.frame, encoding="bgr8"))

def main(args=None):
    rclpy.init(args=args)
    c_id = Controller()
    rclpy.spin(c_id)
    c_id.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

