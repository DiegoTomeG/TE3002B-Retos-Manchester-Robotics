import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description(): 

    config_square= os.path.join(
        get_package_share_directory('paths'), 
                                    'config',
                                    'square_path.yaml')

    config_customPath = os.path.join(
        get_package_share_directory('paths'),
                                    'config',
                                    'custom_path.yaml')


    square_generator = Node(
        package='paths',
        executable='square_generator',
        output='screen',
        parameters=[config_square],
        prefix = 'gnome-terminal --'
    )

    custom_path = Node(
        package='paths', 
        executable='custom_path', 
        output='screen', 
        parameters=[config_customPath], 
 
    )

    odometry = Node(
        package='paths', 
        executable='odometry',
        output = 'screen', 
        prefix = 'gnome-terminal --'
    )

    l_d = LaunchDescription([square_generator, custom_path, odometry])
    return l_d