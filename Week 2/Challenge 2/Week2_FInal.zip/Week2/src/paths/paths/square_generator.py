import rclpy 
import numpy as np
from rclpy.node import Node
from geometry_msgs.msg import Pose2D, Twist, Point
import rclpy.qos
from std_msgs.msg import Float32, String, Bool
import time


class My_publisher(Node):  
    def __init__(self): 
        super().__init__('square_generator')

        #Declaramos los parametros: 
        self.declare_parameters(
            namespace='', 
            parameters=[
                ('angular_speed', rclpy.Parameter.Type.DOUBLE),
                ('linear_speed', rclpy.Parameter.Type.DOUBLE)
            ]
        )

        
        #Nos subscribimos al nodo
        self.left_speed_subscriber = self.create_subscription(String, 'path_selection', self.path_initialization, rclpy.qos.qos_profile_sensor_data)  
        self.positon_subscriber = self.create_subscription(Pose2D, '/Position', self.set_position, rclpy.qos.qos_profile_sensor_data)
        self.speed_publisher = self.create_publisher(Twist, '/cmd_vel',10)  
        self.reset_odometry = self.create_publisher(Bool, '/reset_data',10)
        self.speed_configuration = Twist()
        #self.speed_configuration.angular.x = 0.0
        #self.speed_configuration.angular.y = 0.0
        self.speed_configuration.angular.z = 0.0
        self.speed_configuration.linear.x = 0.0
        #self.speed_configuration.linear.y = 0.0
        #self.speed_configuration.linear.z = 0.0


        #Declaramos las variables del robot
        self.l_square = 1
        self.theta = 90*np.pi/180
                  
        self.v = 0.0
        self.w = 0.0      
    
        self.position = Pose2D()

        self.move = False
        self.sides_recorred = 0
        self.get_logger().info('Square generator node succesfully initialized !')

    def path_initialization(self,msg): 
        #Verificamos que la selección sea del cuadarado
        if msg.data == 'Square': 
            #Realizamos la configración para iniicar recorrido 
            self.v = self.get_parameter('linear_speed').get_parameter_value().double_value
            self.w = self.get_parameter('angular_speed').get_parameter_value().double_value  
            #Indicamos al robot para moverse
            self.move = True
        
        
    def set_position(self,msg): 
        #self.get_logger().info("Recibio dato ")
        self.position = msg

        if self.move: 
            #Iniciamos con la velocidad lineal
            if(self.position.x<1.0): 
                self.get_logger().info('Linea recta')
                self.speed_configuration.angular.z =  0.0
                self.speed_configuration.linear.x = self.v
                self.speed_publisher.publish(self.speed_configuration)
            #Rotamos el bot
            elif(self.position.theta<90.0): 
                self.get_logger().info('Rotar')
                self.speed_configuration.angular.z = self.w
                self.speed_configuration.linear.x = 0.0
                self.speed_publisher.publish(self.speed_configuration)
            #Para facilitar el programa, reseteamos los datos del nodo odometria
            else: 
                self.get_logger().info('Reseting data...')
                reset = Bool()
                reset.data = True
                self.reset_odometry.publish(reset)
                self.sides_recorred +=1
                if(self.sides_recorred>3):
                    self.sides_recorred = 0
                    self.move = False
                    self.get_logger().info('STOP')
                    self.speed_configuration.angular.z =  0.0
                    self.speed_configuration.linear.x =  0.0
                    self.speed_publisher.publish(self.speed_configuration)


def main(args=None): 
    rclpy.init(args=args)
    m_p = My_publisher()
    rclpy.spin(m_p)
    m_p.destroy_node()
    rclpy.shutdown()
    
     
if __name__ == '__main__': 
    main()


 
