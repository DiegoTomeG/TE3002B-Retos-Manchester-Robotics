import rclpy 
import numpy as np
from rclpy.node import Node
from geometry_msgs.msg import Pose2D, Twist, Point
import rclpy.parameter
import rclpy.qos
from std_msgs.msg import Float32, String
import time
import math


class My_publisher(Node):  
    def __init__(self): 
        super().__init__('custom_path')
        #Parametros del nodo
        self.declare_parameters(
            namespace='', 
            parameters=[
                ('v1', rclpy.Parameter.Type.DOUBLE), ('w1', rclpy.Parameter.Type.DOUBLE), #se ininicalizan los parametros para velocidades
                ('v2', rclpy.Parameter.Type.DOUBLE), ('w2', rclpy.Parameter.Type.DOUBLE),#angulares y lineales almacenados en doubles
                ('v3', rclpy.Parameter.Type.DOUBLE), ('w3', rclpy.Parameter.Type.DOUBLE), 
                ('v4', rclpy.Parameter.Type.DOUBLE), ('w4', rclpy.Parameter.Type.DOUBLE),
                ('t', rclpy.Parameter.Type.DOUBLE)
            ]
        )

        #Nos subscribimos al nodo para leer el input
        self.left_speed_subscriber = self.create_subscription(String, 'path_selection', self.path_initialization, rclpy.qos.qos_profile_sensor_data)  
        self.speed_publisher = self.create_publisher(Twist, '/cmd_vel',10)  #se publica la velocidad en el nodo cmd_vel
        self.speed_configuration = Twist()
        #self.speed_configuration.angular.x = 0.0
        #self.speed_configuration.angular.y = 0.0
        self.speed_configuration.angular.z = 0.0 #para un robor diferencial solo hay movimiento en 
        self.speed_configuration.linear.x = 0.0# x y z
        #self.speed_configuration.linear.y = 0.0
        #self.speed_configuration.linear.z = 0.0s

        self.get_logger().info('Custom_path node succesfully initialized !') #se indica que nodo ha sido creado

    def path_initialization(self,msg):
        self.get_logger().info('Mensaje recibido')
        #Comprobamos la selección
        if msg.data == 'Custom path': #si el dato publicado en el topico es custom path, entonces:  
            #Dividimos el tiempo en partes igaules
            t = self.get_parameter('t').get_parameter_value().double_value
            t = t/8 #se divide el tiempo total en partes iguales 
            #t = 10
            #t = t/8
            #v = [0.2,0.2,0.2,0.2]
            #w = [0.1,-0.2,0.15,-0.05]
            for i in range(4):
                print(i)
                #Seleccionamos la velocidad correspondiente
                v_string = f'v{i+1}'
                w_string = f'w{i+1}'
            
                #Movemos el bot
                self.get_logger().info("Recta") #se indica que el robot se mueve hacia adelante
                self.speed_configuration.linear.x = 0.0 #inicia la velocidad en 0 para evitar malas lecturas
                self.speed_configuration.angular.z = self.get_parameter(w_string).get_parameter_value().double_value #se obtiene el parametro que indica la velocidad angular
                self.speed_publisher.publish(self.speed_configuration) #se publica la speed configuration
                time.sleep(t)
                self.get_logger().info("Rotar") #se indica que el robot esta girando
                self.speed_configuration.linear.x = self.get_parameter(v_string).get_parameter_value().double_value
                self.speed_configuration.angular.z = 0.0
                self.speed_publisher.publish(self.speed_configuration)
                time.sleep(t)

            self.get_logger().info('STOP') #en cuanto se complete el ciclo, el robot debe detenerse
            self.speed_configuration.linear.x = 0.0 #velocidad lineal y angular regresan a 0
            self.speed_configuration.angular.z = 0.0 
            self.speed_publisher.publish(self.speed_configuration)
            

def main(args=None): 
    rclpy.init(args=args)
    m_p = My_publisher()
    rclpy.spin(m_p)
    m_p.destroy_node()
    rclpy.shutdown()
    
     
if __name__ == '__main__': 
    main()
    

