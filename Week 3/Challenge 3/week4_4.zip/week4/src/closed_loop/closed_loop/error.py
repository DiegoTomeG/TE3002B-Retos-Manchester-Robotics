import rclpy 
import numpy as np
from rclpy.node import Node
from geometry_msgs.msg import Pose2D, Point
import rclpy.qos
from std_msgs.msg import Float32, Bool, Empty
from srv_int.msg import Error2D

class My_publisher(Node):  
    def __init__(self): 
        super().__init__('error_node') #Inicializamos el nodo
        
        #Nos subscribimos al tópico de posición
        self.position_subscriber = self.create_subscription(Pose2D, '/Position', self.calculate_error, rclpy.qos.qos_profile_sensor_data)
        #CReamos una subscripcion para acutalizar el putno de referencia
        #Creamos un publisher para mandar el error
        self.error_publisher = self.create_publisher(Error2D, 'error', 10)
        #Declaramos el timer asociado al publisher
        
        self.triangle = [[0.7,0.0], [0.35,0.85], [0.0,0.0]]        
        self.square = [[0.7,0.0], [0.7,0.7], [0.0,0.7],[0.0,0.0]]
        self.pentagon = [[0.63,0.0], [0.82,0.6], [0.31,0.95],[-0.2,0.6], [0.0,0.0]]
        self.hexagon = [[0.5,0.0], [0.75,0.43], [0.5,0.85],[0.0,0.85], [-0.25,0.43], [0.0,0.0]]

        #se realiza cambio dependiendo de la figura
        self.selection = self.square
        self.index_point = 0
        
        #Crear una variable de error
        self.error = Error2D()
        self.setpoint = Float32()
        self.move = True

        self.get_logger().info('Error node succesfully initialized !')
        
    def calculate_error(self,msg):
        if self.move: 
            #Calculamos la distancia al punto trianglex       
            x_reference = self.selection[self.index_point][0]
            y_reference = self.selection[self.index_point][1]

            x_distance = x_reference- msg._x        
            y_distance = y_reference- msg._y
            distance = np.sqrt(x_distance**2 + y_distance**2)   
            
            try: 
                x_reference = x_reference - self.selection[self.index_point-1][0]    
                y_reference = y_reference - self.selection[self.index_point-1][1]

            except: 
                pass

            try: 
                angle = np.arctan2(y_reference, x_reference)
            except: 
                angle = 0
    
            angle_degrees = np.degrees(angle)
            
            if angle_degrees < 0: 
                angle_degrees +=360

            angle_error = angle_degrees - msg._theta

            self.setpoint.data = angle_degrees

            #Copiamos a la variable del error
            self.error.distance_error = distance
            self.error.theta_error = angle_error
            
            if (distance <= 0.17 and angle_error <=1.0): 
                self.index_point +=1

                if self.index_point >= len(self.selection): 
                    self.move = False

                    self.error.distance_error = 0.0
                    self.error.theta_error = 0.0
                    
            self.error_publisher.publish(self.error)


#Inicialización del nodo
def main(args=None): 
    rclpy.init(args=args)
    m_p = My_publisher()
    rclpy.spin(m_p)
    m_p.destroy_node()
    rclpy.shutdown()
    
     
if __name__ == '__main__': 
    main()