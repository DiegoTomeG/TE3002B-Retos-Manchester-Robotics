import rclpy 
import numpy as np
from rclpy.node import Node
from geometry_msgs.msg import Pose2D, Point, Twist
import rclpy.qos
from std_msgs.msg import Float32, Bool, Empty
from srv_int.msg import Error2D

class My_publisher(Node):  
    def __init__(self): 
        super().__init__('controller_node') #Inicializamos el nodo
        
        self.error_subscriber = self.create_subscription(Error2D, '/error', self.control_puzzlebot, rclpy.qos.qos_profile_sensor_data)
        #CReamos una subscripcion para acutalizar el putno de referencia
        self.speed_publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        
        #variables del controlador para velocidad lineal y angular
        self.kv = 0.4
        self.kw = 0.03
    
        #velocidades para limitar la velocidad lineal del puzzlebot
        self.v = 0.0
        self.v_max = 0.4
        self.v_min = 0.05

        #limitar la velocidad angular del puzzlebot
        self.w = 0.0
        self.w_max = 0.45
        self.w_min = -0.3

        #variables para almacenar el error en ambas velocidades
        self.e_theta = 0.0
        self.e_distance = 0.0

        self.speed_bot = Twist() #la velocidad se define como tipo de mensaje twist

        self.get_logger().info('Controller node succesfully initialized !')
        
    def control_puzzlebot(self, msg): #funcion para indicar que el robot se ha detenido 
       if msg.theta_error == 0.0 and msg.distance_error == 0.0:
            self.speed_bot.linear.x = 0.0
            self.speed_bot.angular.z = 0.0 
           
       else:  
            #se obtiene el error
            self.get_logger().info('Entro en esta función loco')
            self.e_theta = msg.theta_error #variables para almancear el error a partir del topico
            self.e_distance = msg.distance_error

            self.v = self.e_distance * self.kv #multiplicar el error utilizando el controlador

            #se delimita la velocidad para evitar picos
            if self.v > self.v_max: 
                self.v = self.v_max

            elif self.v < self.v_min: 
                self.v = 0.0

            self.w = self.e_theta * self.kw #multiplicar el error de la velocidad angular

            if self.w > self.w_max: #se limita la velocidad angular para evitar picos
                self.w = self.w_max

            elif self.w < self.w_min: 
                self.w = self.w_min

            self.speed_bot.linear.x = self.v #se asigna la velocidad lineal controlada 
            self.speed_bot.angular.z = self.w #se asigna la velocidad angular controlaada

       self.get_logger().info(f'v: {self.v}, w: {self.w}')
       self.speed_publisher.publish(self.speed_bot) #se publican en el topico las nuevas velocidades

        
#Inicialización del nodo
def main(args=None): 
    rclpy.init(args=args)
    m_p = My_publisher()
    rclpy.spin(m_p)
    m_p.destroy_node()
    rclpy.shutdown()
    
     
if __name__ == '__main__': 
    main()