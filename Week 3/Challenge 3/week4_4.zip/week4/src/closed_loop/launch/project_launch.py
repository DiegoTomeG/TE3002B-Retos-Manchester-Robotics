import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description(): 

    odometry = Node( #nodo de odometry perteneciente al paquete closed loop
    package='closed_loop', 
    executable='odometry', 
    output = 'screen', 
    #prefix = 'gnome-terminal --'
    )

    error = Node( #nodo de error  perteneciente al paquete closed loop
    package='closed_loop', 
    executable='error', 
    output = 'screen', 
    #prefix = 'gnome-terminal --'
    )

    controller = Node(  #nodo de controller perteneciente al paquete closed loop
    package='closed_loop', 
    executable='controller', 
    output = 'screen', 
    #prefix = 'gnome-terminal --'
    )


    l_d = LaunchDescription([odometry, error, controller])
    return l_d