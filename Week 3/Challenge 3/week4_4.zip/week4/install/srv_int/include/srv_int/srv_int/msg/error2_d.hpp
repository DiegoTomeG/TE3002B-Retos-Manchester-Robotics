// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SRV_INT__MSG__ERROR2_D_HPP_
#define SRV_INT__MSG__ERROR2_D_HPP_

#include "srv_int/msg/detail/error2_d__struct.hpp"
#include "srv_int/msg/detail/error2_d__builder.hpp"
#include "srv_int/msg/detail/error2_d__traits.hpp"

#endif  // SRV_INT__MSG__ERROR2_D_HPP_
