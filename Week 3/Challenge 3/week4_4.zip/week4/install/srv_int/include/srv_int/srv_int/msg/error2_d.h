// generated from rosidl_generator_c/resource/idl.h.em
// with input from srv_int:msg/Error2D.idl
// generated code does not contain a copyright notice

#ifndef SRV_INT__MSG__ERROR2_D_H_
#define SRV_INT__MSG__ERROR2_D_H_

#include "srv_int/msg/detail/error2_d__struct.h"
#include "srv_int/msg/detail/error2_d__functions.h"
#include "srv_int/msg/detail/error2_d__type_support.h"

#endif  // SRV_INT__MSG__ERROR2_D_H_
