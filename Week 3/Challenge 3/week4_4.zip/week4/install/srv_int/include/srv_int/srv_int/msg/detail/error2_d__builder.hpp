// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from srv_int:msg/Error2D.idl
// generated code does not contain a copyright notice

#ifndef SRV_INT__MSG__DETAIL__ERROR2_D__BUILDER_HPP_
#define SRV_INT__MSG__DETAIL__ERROR2_D__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "srv_int/msg/detail/error2_d__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace srv_int
{

namespace msg
{

namespace builder
{

class Init_Error2D_theta_error
{
public:
  explicit Init_Error2D_theta_error(::srv_int::msg::Error2D & msg)
  : msg_(msg)
  {}
  ::srv_int::msg::Error2D theta_error(::srv_int::msg::Error2D::_theta_error_type arg)
  {
    msg_.theta_error = std::move(arg);
    return std::move(msg_);
  }

private:
  ::srv_int::msg::Error2D msg_;
};

class Init_Error2D_distance_error
{
public:
  Init_Error2D_distance_error()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Error2D_theta_error distance_error(::srv_int::msg::Error2D::_distance_error_type arg)
  {
    msg_.distance_error = std::move(arg);
    return Init_Error2D_theta_error(msg_);
  }

private:
  ::srv_int::msg::Error2D msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::srv_int::msg::Error2D>()
{
  return srv_int::msg::builder::Init_Error2D_distance_error();
}

}  // namespace srv_int

#endif  // SRV_INT__MSG__DETAIL__ERROR2_D__BUILDER_HPP_
