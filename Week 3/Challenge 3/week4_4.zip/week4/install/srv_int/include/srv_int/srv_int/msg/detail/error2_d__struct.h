// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from srv_int:msg/Error2D.idl
// generated code does not contain a copyright notice

#ifndef SRV_INT__MSG__DETAIL__ERROR2_D__STRUCT_H_
#define SRV_INT__MSG__DETAIL__ERROR2_D__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/Error2D in the package srv_int.
typedef struct srv_int__msg__Error2D
{
  double distance_error;
  double theta_error;
} srv_int__msg__Error2D;

// Struct for a sequence of srv_int__msg__Error2D.
typedef struct srv_int__msg__Error2D__Sequence
{
  srv_int__msg__Error2D * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} srv_int__msg__Error2D__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SRV_INT__MSG__DETAIL__ERROR2_D__STRUCT_H_
