import rclpy 
import numpy as np
from rclpy.node import Node
from geometry_msgs.msg import Pose2D, Point, Twist
import rclpy.qos
from std_msgs.msg import Float32, Bool, String
from srv_int.msg import Error2D

class My_publisher(Node):  
    def __init__(self): 
        super().__init__('controller_node') #Inicializamos el nodo
        
        self.error_subscriber = self.create_subscription(Error2D, '/error', self.control_puzzlebot, rclpy.qos.qos_profile_sensor_data)
        #CReamos una subscripcion para acutalizar el putno de referencia
        #self.setpoint_sub = self.create_subscription(Empty, 'next_point', self.act_setpoint, rclpy.qos.qos_profile_sensor_data)
        self.speed_publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        
        #Creamos una suscripción al traffic light detector: 
        self.traffic_light_sub = self.create_subscription(String, '/color_trafficLight', self.traffic_light_callback, rclpy.qos.qos_profile_sensor_data)
        #variables del controlador para velocidad lineal y angular
        self.kv = 0.0
        self.kw = 0.0
        
    
        #velocidades para limitar la velocidad del puzzlebot
        self.v = 0.0
        self.v_max = 0.2
        self.v_min = 0.05

        self.w = 0.0
        self.w_max = 0.35
        self.w_min = -0.3

        #error 
        self.e_theta = 0.0
        self.e_distance = 0.0

        
        self.speed_bot = Twist()

        self.angle_corrected = False
        self.move = True

        self.get_logger().info('Controller node succesfully initialized !')
        
    def control_puzzlebot(self, msg):
        #Obtrenemos las varaibles de error
        self.e_theta = msg.theta_error
        self.e_distance= msg.distance_error

        #Priorizamos la correción del ángulo:
        if not self.angle_corrected: 

            self.w = self.e_theta * self.kw

            #Saturamos la salida del controlador
            if self.w > self.w_max: 
                self.w = self.w_max

            elif self.w < self.w_min: 
                self.w = self.w_min

            self.v = 0.0

        else: #El ángulo ya fue corregido: 

            self.w = self.e_theta * self.kw
            self.v = self.e_distance * self.kv

            #Saturamos la salida del controlador
            if self.w > self.w_max: 
                self.w = self.w_max

            elif self.w < self.w_min: 
                self.w = self.w_min

            if self.v > self.v_max: 
                self.v = self.v_max

            elif self.v < self.v_min: 
                self.v = 0.1

        #Nuestro controlador considerara que un angulo mayor a 5 grados
        #indica que el robot debe priorizar el ángulo

        if self.e_theta > 5.0 or self.e_theta < -5.0: 
            self.angle_corrected = False
        elif self.e_theta <1.0 or self.e_theta > -1.0: 
            self.angle_corrected = True


        #Publicamos la velocidad
        self.speed_bot.linear.x = self.v
        self.speed_bot.angular.z = self.w

        if (self.e_theta == 0.0 and self.e_distance == 0.0) or (not self.move): 
            self.speed_bot.linear.x = 0.0
            self.speed_bot.angular.z = 0.0

        self.get_logger().info(f'V: {self.kv}, w: {self.kw}')
        self.speed_publisher.publish(self.speed_bot)

    def traffic_light_callback(self, msg): 
        self.get_logger().info("Cambio de velocidad")
        color = msg.data
        if color == 'r':
            self.kv = 0.0
            self.kw = 0.0
            self.move = False
        elif color == 'y':
            self.kv = 0.1
            self.kw = 0.015
            self.move = True
        elif color == 'g':
            self.kv = 0.2
            self.kw = 0.03
            self.move = True

#Inicialización del nodo
def main(args=None): 
    rclpy.init(args=args)
    m_p = My_publisher()
    rclpy.spin(m_p)
    m_p.destroy_node()
    rclpy.shutdown()
    
     
if __name__ == '__main__': 
    main()