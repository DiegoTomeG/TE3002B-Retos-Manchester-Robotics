import rclpy 
import numpy as np
from rclpy.node import Node
from geometry_msgs.msg import Pose2D
import rclpy.qos
from std_msgs.msg import Float32, Bool


class My_publisher(Node):  
    def __init__(self): 
        super().__init__('odometry_node') #Inicializamos el nodo
        
        #Nos subscribimos a los nodos de las velocidades
        self.left_speed_subscriber = self.create_subscription(Float32, 'VelocityEncL', self.read_left, rclpy.qos.qos_profile_sensor_data)    
        self.right_speed_subscriber = self.create_subscription(Float32, 'VelocityEncR', self.read_right, rclpy.qos.qos_profile_sensor_data)
       
        #Creamos el publisher para la posición del robot:
        self.position_publisher = self.create_publisher(Pose2D, 'Position', 10)
        #Declaramos el timer asociado al publisher
        self.timer_period = 0.01 #Declaramos el periodo del publsher como 100 HZ
        self.timer = self.create_timer(self.timer_period, self.position_callback)
        
        #Declaramos las variables del robot
        self.l = 0.19 #Distancia entre ruedas
        self.r = 0.05 #Diametro de las ruedas
        self.right = Float32() #Variable para velocidad derecha
        self.left = Float32() #Variable para velocidad izquierda

	#Variables para la velocidad
        self.xp = 0.0
        self.yp = 0.0
        self.thetap = 0.0

	#Variables para la posición
        self.x =  0.0
        self.y = 0.0
        self.theta = 0.0

        #Variables del robot
        self.position = Pose2D()
               
        self.get_logger().info('Odometry node succesfully initialized !')
    
    def position_callback(self): 

    	#Calculamos la velocidad para x, y y theta
        self.xp = self.r*((self.right.data+self.left.data)/2)*np.cos(self.theta)
        self.yp = self.r*((self.right.data+self.left.data)/2)*np.sin(self.theta)
        self.thetap = self.r*(self.right.data - self.left.data)/self.l

        #Integramos para obtener la posición
        self.x += self.xp * self.timer_period
        self.y += self.yp * self.timer_period
        self.theta += self.thetap * self.timer_period

        #Copiamos la información al dato tipo Pose2D
        self.position._x = self.x
        self.position._y = self.y
        self.position._theta = self.theta*180/np.pi

	#Publicamos la posición
        self.position_publisher.publish(self.position)

    def read_left(self, msg):
	    #Copiamos la información a la variable del nodo
        self.left = msg
    
    def read_right(self, msg): 
        #Copiamos la información a la variable del nodo
        self.right = msg
            
    
#Inicialización del nodo
def main(args=None): 
    rclpy.init(args=args)
    m_p = My_publisher()
    rclpy.spin(m_p)
    m_p.destroy_node()
    rclpy.shutdown()
    
     
if __name__ == '__main__': 
    main()