import rclpy
from rclpy.node import Node
import numpy as np
import cv2
from cv_bridge import CvBridge
from sensor_msgs.msg import Image
from std_msgs.msg import String

class ColorId(Node):
    def __init__(self):
        super().__init__('color_detector')
        self.bridge = CvBridge()
        dt = 0.03
        self.subscription = self.create_subscription(Image, '/video_source/raw', self.camera_callback, 10)
        self.subscription
        self.timer = self.create_timer(dt, self.timer_callback)
        self.light_detection_pub = self.create_publisher(Image, '/image_processing/color_id', 10)
        self.traffic_light_pub = self.create_publisher(String, '/color_trafficLight', 10)
        
        # Definimos los valores para la máscara de colores
        self.lower_red = np.array([0, 100, 20], np.uint8)
        self.upper_red = np.array([5, 255, 255], np.uint8)
        self.lower_red2 = np.array([175, 100, 20], np.uint8)
        self.upper_red2 = np.array([179, 255, 255], np.uint8)
        self.lower_green = np.array([40, 100, 0], np.uint8)
        self.upper_green = np.array([80, 255, 255], np.uint8)
        self.lower_yellow = np.array([15, 100, 20], np.uint8)
        self.upper_yellow = np.array([45, 255, 255], np.uint8)
        
        # Dimensiones de la imagen
        self.frame_width = 160
        self.frame_height = 90     

        # Variables para la imagen 
        self.frame = None  
        self.color = String()
        self.get_logger().info('Traffic light node succesfully initialized!!')

    def draw_circles(self, mask, color, label):
        # Encuentra los contornos en la máscara
        countours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for c in countours:
            area = cv2.contourArea(c)
            if area > 300:
                M = cv2.moments(c)
                if M["m00"] == 0: 
                    M["m00"] = 1
                x = int(M["m10"] / M["m00"])
                y = int(M['m01'] / M['m00'])
                newCountour = cv2.convexHull(c)
                cv2.circle(self.frame, (x, y), 7, (128, 0, 255), -1)
                cv2.drawContours(self.frame, [newCountour], 0, color, 3)
                # Etiqueta de color
                cv2.putText(self.frame, label, (x - 50, y - 50), cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)
   
    def camera_callback(self, msg):
        try:
            self.frame = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            # Reajustamos el tamaño
            self.frame = cv2.resize(self.frame, (self.frame_width, self.frame_height))
            self.frame = self.adjust_gamma(0.5)
        except:
            self.get_logger().info('Failed to convert image to CV2')
    
    def adjust_gamma(self, gamma=1.0): 
        inv_gamma = 1.0 / gamma
        table = np.array([((i / 255.0) ** inv_gamma) * 255 for i in np.arange(0, 256)]).astype("uint8")
        return cv2.LUT(self.frame.copy(), table)
    
    def timer_callback(self):
        if self.frame is not None: 
            frameHSV = cv2.cvtColor(self.frame, cv2.COLOR_BGR2HSV)
            # Máscaras para cada color
            maskVerde = cv2.inRange(frameHSV, self.lower_green, self.upper_green)  # Verde
            maskAmarillo = cv2.inRange(frameHSV, self.lower_yellow, self.upper_yellow)  # Amarillo
            maskRed1 = cv2.inRange(frameHSV, self.lower_red, self.upper_red)  # Rojo (parte 1)
            maskRed2 = cv2.inRange(frameHSV, self.lower_red2, self.upper_red2)  # Rojo (parte 2)
            maskRed = cv2.add(maskRed1, maskRed2)  # Combinar máscaras de rojo
            
            # Llama a la función para dibujar los contornos para cada color
            self.draw_circles(maskVerde, (0, 255, 0), 'Verde')  # Verde
            self.draw_circles(maskAmarillo, (0, 255, 255), 'Amarillo')  # Amarillo
            self.draw_circles(maskRed, (0, 0, 255), 'Rojo')  # Rojo
            
            self.light_detection_pub.publish(self.bridge.cv2_to_imgmsg(self.frame, encoding="bgr8"))

            # Calculamos el color de mayor presencia
            area_red = cv2.countNonZero(maskRed)
            area_green = cv2.countNonZero(maskVerde)
            area_yellow = cv2.countNonZero(maskAmarillo)

            dominant_color = None

            if area_red > area_green and area_red > area_yellow:
                dominant_color = 'r'
            elif area_green > area_red and area_green > area_yellow:
                dominant_color = 'g'
            elif area_yellow > area_red and area_yellow > area_green:
                dominant_color = 'y'
            
            if dominant_color is not None:
                self.color.data = dominant_color
                self.traffic_light_pub.publish(self.color) 

def main(args=None):
    rclpy.init(args=args)
    c_id = ColorId()
    rclpy.spin(c_id)
    c_id.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

'''import rclpy
from rclpy.node import Node
import numpy as np
import cv2
from cv_bridge import CvBridge
from sensor_msgs.msg import Image
from std_msgs.msg import String

class ColorId(Node):
    def __init__(self):
        super().__init__('color_detector')
        self.bridge = CvBridge()
        dt = 0.1
        self.subscription = self.create_subscription(Image, '/video_source/raw', self.camera_callback, 10)
        self.subscription
        self.timer = self.create_timer(dt, self.timer_callback)
        self.light_detection_pub = self.create_publisher(Image, '/image_processing/color_id', 10)

        self.traffic_light_pub = self.create_publisher(String, '/color_trafficLight', 10)
        

        #Definimos los valores para la máscara de colores
        self.lower_red = np.array([0, 100, 20], np.uint8)
        self.upper_red = np.array([5, 255, 255], np.uint8)

        self.lower_red2 =np.array([175, 100, 20], np.uint8)
        self.upper_red2 = np.array([179, 255, 255], np.uint8)

        self.lower_green = np.array([40, 100, 0], np.uint8)
        self.upper_green = np.array([80, 255, 255], np.uint8)

        self.lower_yellow = np.array([15, 100, 20], np.uint8)
        self.upper_yellow = np.array([45, 255, 255], np.uint8)

        #Dimensiones de la imágen
        self.frame_width = 160
        self.frame_height = 90     

        #Variables para la imagen 
        self.frame = None  
        self.color = String()

        self.get_logger().info('Traffic light node succesfully initialized!!')

    def draw_circles(self, mask, color, label):
        # Encuentra los contornos en la máscara
        countours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for c in countours:
            area = cv2.contourArea(c)
            if area > 300:
                M = cv2.moments(c)
                if M["m00"] == 0: 
                    M["m00"] = 1
                x = int(M["m10"] / M["m00"])
                y = int(M['m01'] / M['m00'])
                newCountour = cv2.convexHull(c)
                cv2.circle(self.frame, (x, y), 7, (128, 0, 255), -1)
                cv2.drawContours(self.frame, [newCountour], 0, color, 3)
                # Etiqueta de color
                cv2.putText(self.frame, label, (x - 50, y - 50), cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)
   
    def camera_callback(self, msg):
        try:
            self.frame = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            #Reajustamos el tamaño
            self.frame = cv2.resize(self.frame, (self.frame_width, self.frame_height))
            self.frame = self.adjust_gamma(1.0)
        except:
            self.get_logger().info('Failed to convert image to CV2')
    
    def adjust_gamma(self, gamma = 1.0): 
        inv_gamma = 1.0 / gamma
        table = np.array([((i / 255.0) ** inv_gamma) * 255 for i in np.arange(0, 256)]).astype("uint8")
        return cv2.LUT(self.frame.copy(), table)
    
    def erode(self,mask): 
        kernel = np.ones((6, 6), np.uint8)
        return cv2.erode(mask, kernel, iterations=1)
    
    def timer_callback(self):

        if self.frame is not None: 
            
            #Convertimos el frame a escala de grises
            gray_frame = cv2.cvtColor(self.frame, cv2.COLOR_BGR2GRAY)

            frameHSV = cv2.cvtColor(self.frame, cv2.COLOR_BGR2HSV)

            # Máscaras para cada color
            maskVerde = cv2.inRange(frameHSV, self.lower_green,self.upper_green)  # Verde
            maskAmarillo = cv2.inRange(frameHSV, self.lower_yellow, self.upper_yellow)  # Amarillo
            maskRed1 = cv2.inRange(frameHSV, self.lower_red, self.upper_red)  # Rojo (parte 1)
            maskRed2 = cv2.inRange(frameHSV, self.lower_red2, self.upper_red2)  # Rojo (parte 2)
            maskRed = cv2.add(maskRed1, maskRed2)  # Combinar máscaras de rojo

            kernel = np.ones((3,3), np.uint8)  # Kernel de tamaño 5x5
            
            erosiongreen = maskVerde #self.erode(maskVerde)
            erosionamarillod = maskAmarillo # self.erode(maskAmarillo)
            erosionred = maskRed#self.erode(maskRed)
 
            # Llama a la función para dibujar los contornos para cada color
            self.draw_circles(erosiongreen, (0, 255, 0), 'Verde')  # Verde
            self.draw_circles(erosionamarillod, (0, 255, 255), 'Amarillo')  # Amarillo
            self.draw_circles(erosionred, (0, 0, 255), 'Rojo')  # Rojo

            self.light_detection_pub.publish(self.bridge.cv2_to_imgmsg(self.frame, encoding="bgr8"))

            #Calculamso el color de mayor presencia: 
            area_red = cv2.countNonZero(erosionred)
            area_green = cv2.countNonZero(erosiongreen)
            area_yellow = cv2.countNonZero(erosionamarillod)

            dominant_color = None

            if area_red > area_green and area_red > area_yellow:
                dominant_color = 'r'
            elif area_green > area_red and area_green > area_yellow:
                dominant_color = 'g'
            elif area_yellow > area_red and area_yellow > area_green:
                dominant_color = 'y'
            

            if dominant_color is not None:
                self.color.data = dominant_color
                self.traffic_light_pub.publish(self.color) 



def main(args=None):
    rclpy.init(args=args)
    c_id = ColorId()
    rclpy.spin(c_id)
    c_id.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()'''