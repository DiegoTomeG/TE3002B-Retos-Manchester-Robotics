// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from srv_int:msg/Error2D.idl
// generated code does not contain a copyright notice

#ifndef SRV_INT__MSG__DETAIL__ERROR2_D__STRUCT_HPP_
#define SRV_INT__MSG__DETAIL__ERROR2_D__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__srv_int__msg__Error2D __attribute__((deprecated))
#else
# define DEPRECATED__srv_int__msg__Error2D __declspec(deprecated)
#endif

namespace srv_int
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct Error2D_
{
  using Type = Error2D_<ContainerAllocator>;

  explicit Error2D_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->distance_error = 0.0;
      this->theta_error = 0.0;
    }
  }

  explicit Error2D_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->distance_error = 0.0;
      this->theta_error = 0.0;
    }
  }

  // field types and members
  using _distance_error_type =
    double;
  _distance_error_type distance_error;
  using _theta_error_type =
    double;
  _theta_error_type theta_error;

  // setters for named parameter idiom
  Type & set__distance_error(
    const double & _arg)
  {
    this->distance_error = _arg;
    return *this;
  }
  Type & set__theta_error(
    const double & _arg)
  {
    this->theta_error = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    srv_int::msg::Error2D_<ContainerAllocator> *;
  using ConstRawPtr =
    const srv_int::msg::Error2D_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<srv_int::msg::Error2D_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<srv_int::msg::Error2D_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      srv_int::msg::Error2D_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<srv_int::msg::Error2D_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      srv_int::msg::Error2D_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<srv_int::msg::Error2D_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<srv_int::msg::Error2D_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<srv_int::msg::Error2D_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__srv_int__msg__Error2D
    std::shared_ptr<srv_int::msg::Error2D_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__srv_int__msg__Error2D
    std::shared_ptr<srv_int::msg::Error2D_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Error2D_ & other) const
  {
    if (this->distance_error != other.distance_error) {
      return false;
    }
    if (this->theta_error != other.theta_error) {
      return false;
    }
    return true;
  }
  bool operator!=(const Error2D_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Error2D_

// alias to use template instance with default allocator
using Error2D =
  srv_int::msg::Error2D_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace srv_int

#endif  // SRV_INT__MSG__DETAIL__ERROR2_D__STRUCT_HPP_
