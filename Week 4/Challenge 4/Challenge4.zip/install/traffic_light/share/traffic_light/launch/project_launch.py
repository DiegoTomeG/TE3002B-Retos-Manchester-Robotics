import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description(): 

    odometry = Node(
    package='traffic_light', 
    executable='odometry', 
    output = 'screen', 
    #prefix = 'gnome-terminal --'
    )

    error = Node(
    package='traffic_light', 
    executable='error', 
    output = 'screen', 
    #prefix = 'gnome-terminal --'
    )

    controller = Node(
    package='traffic_light', 
    executable='controller', 
    output = 'screen', 
    #prefix = 'gnome-terminal --'
    )

    traffic_light = Node(
        package='traffic_light', 
        executable = 'color_detector',
        output = 'screen', 
    )

    l_d = LaunchDescription([odometry, error, controller, traffic_light])
    return l_d