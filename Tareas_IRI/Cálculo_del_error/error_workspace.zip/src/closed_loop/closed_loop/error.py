import rclpy 
import numpy as np
from rclpy.node import Node
from geometry_msgs.msg import Pose2D, Point
import rclpy.qos
from std_msgs.msg import Float32, Bool, Empty
from srv_int.msg import Error2D

class My_publisher(Node):  
    def __init__(self): 
        super().__init__('error_node') #Inicializamos el nodo
        
        #Nos subscribimos al tópico de posición
        self.position_subscriber = self.create_subscription(Pose2D, '/Position', self.calculate_error, rclpy.qos.qos_profile_sensor_data)
        #CReamos una subscripcion para acutalizar el putno de referencia
        self.setpoint_sub = self.create_subscription(Empty, 'next_point', self.act_setpoint, rclpy.qos.qos_profile_sensor_data)
        self.index = 0
        #Creamos un publisher para mandar el error
        self.error_publisher = self.create_publisher(Error2D, 'error', 10)
        #Declaramos el timer asociado al publisher
        self.timer_period = 0.01 #Declaramos el periodo del publsher como 100 HZ
        self.timer = self.create_timer(self.timer_period, self.publish_error)

        #Prueba de error a un punto         
        self.point = Point()
        self.point._x = 1.0
        self.point._y = 1.0

        '''La siguiente sección comentada sirve para el calculo de error en una trayectoria cuadrada. '''
        #Definimos los putnos o setpoints del cuadrado: 
        #self.x_points = [1.0, 1.0, 0.0, 0.0]
        #self.y_points = [0.0, 1.0, 1.0, 0.0]
        
        #Crear una variable de error
        self.error = Error2D()

        self.get_logger().info('Error node succesfully initialized !')
        
    def calculate_error(self,msg):
        #Calculamos la distancia al punto 
        
        x_reference = self.point._x
        y_reference = self.point._y
        
        '''La siguiente sección está comentada, pero es útil para
        calcular el error en una trayectoria cuadrada'''
        #x_reference = self.x_points[self.index]
        #y_reference = self.y_points[self.index]

        x_distance = x_reference- msg._x
        y_distance = y_reference- msg._y
        distance = np.sqrt(x_distance**2 + y_distance**2)   


        try: 
            angle = np.arctan2(y_reference,x_reference)
        except: 
            angle = 0

        angle_degrees = np.degrees(angle)
        angle_error = angle_degrees - msg._theta

        #Copiamos a la variable del error
        self.error.distance_error = distance
        self.error.theta_error = angle_error

    def publish_error(self): 
        self.error_publisher.publish(self.error)

    def act_setpoint(self, msg):
       self.get_logger().info('Next point')
       self.index+=1 #La siguiente sección es útil para el error en una trayectoria (cuadrado): 
       if(self.index>3): 
        self.index = 3

#Inicialización del nodo
def main(args=None): 
    rclpy.init(args=args)
    m_p = My_publisher()
    rclpy.spin(m_p)
    m_p.destroy_node()
    rclpy.shutdown()
    
     
if __name__ == '__main__': 
    main()