from srv_int.msg._error2_d import Error2D  # noqa: F401
